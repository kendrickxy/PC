//Global Variables
var canvas, ctx, width, height, img;